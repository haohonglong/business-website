<?php

namespace app\api\model;

use think\Model;

class OrderProduct extends Model
{
    
}