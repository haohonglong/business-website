<?php

namespace app\api\model;

use think\Model;

class ResourceProductCategory extends Model
{
    //
}
