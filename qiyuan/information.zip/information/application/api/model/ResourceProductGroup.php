<?php

namespace app\api\model;

use think\Model;

class ResourceProductGroup extends Model
{
    //
}
