<?php

namespace app\api\model;

use think\Model;

class ResourceProductSku extends Model
{
    //
}
