<?php

namespace app\api\model;

use think\Model;

class ResourceProduct extends Model
{
    //
}
