<?php

namespace app\api\model;

use think\Model;

class PaymentLog extends Model
{
    
}
