<?php

namespace app\api\model;

use think\Model;

class UserForm extends Model
{
    //
}
