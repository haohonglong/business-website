<?php

namespace app\api\model;

use think\Model;

class Setting extends Model
{
    
    
}
