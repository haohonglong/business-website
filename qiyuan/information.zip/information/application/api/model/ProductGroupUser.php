<?php

namespace app\api\model;

use think\Model;

class ProductGroupUser extends Model
{
    //
}
