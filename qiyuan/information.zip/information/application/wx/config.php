<?php
//配置文件
return [
	'default_return_type'=>'json',
	'wxAppId' => 'wx4b9ec6fbfba5e3e3',
	'wxAppSecret' => 'e91330f518138c8ccb4e3b4425362923'
];