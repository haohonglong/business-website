<?php

namespace app\wx\model;

use think\Model;

class Loginlog extends Model
{
    
}
