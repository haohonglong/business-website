<?php

namespace app\wx\model;

use think\Model;

class Wxuser extends Model
{
    
}
