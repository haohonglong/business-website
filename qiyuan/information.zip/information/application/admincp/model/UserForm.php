<?php

namespace app\admincp\model;

use think\Model;

class UserForm extends Model
{


}
