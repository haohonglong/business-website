<?php

namespace app\admincp\model;

use think\Model;

class Category extends Model
{
    //
}
