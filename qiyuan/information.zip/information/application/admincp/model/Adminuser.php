<?php

namespace app\admincp\model;

use think\Model;

class Adminuser extends Model
{
    
}
