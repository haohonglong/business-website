<?php

namespace app\admincp\model;

use think\Model;

class ProductLotteryUser extends Model
{
    //
}
