<?php

namespace app\admincp\model;

use think\Model;

class Setting extends Model
{
    
    
}
