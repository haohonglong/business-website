<?php

namespace app\admincp\model;

use think\Model;

class ResourceProductCategory extends Model
{
    //
}
