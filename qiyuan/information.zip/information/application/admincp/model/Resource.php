<?php

namespace app\admincp\model;

use think\Model;

class Resource extends Model
{
    //
}
