<?php

namespace app\admincp\model;

use think\Model;

class ResourceProduct extends Model
{
    //
}
