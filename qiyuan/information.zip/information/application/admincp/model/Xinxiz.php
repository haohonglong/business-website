<?php

namespace app\admincp\model;

use think\Model;

class Xinxiz extends Model
{


}
