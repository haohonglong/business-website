<?php

namespace app\admincp\model;

use think\Model;

class ResourceProductGroup extends Model
{
    //
}
