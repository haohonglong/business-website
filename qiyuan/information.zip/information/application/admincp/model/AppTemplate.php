<?php

namespace app\admincp\model;

use think\Model;

class AppTemplate extends Model
{
    
    
}
