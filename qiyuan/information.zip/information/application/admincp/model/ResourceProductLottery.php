<?php

namespace app\admincp\model;

use think\Model;

class ResourceProductLottery extends Model
{

   
}
