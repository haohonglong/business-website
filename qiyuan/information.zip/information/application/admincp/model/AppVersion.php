<?php

namespace app\admincp\model;

use think\Model;

class AppVersion extends Model
{
    
    
}
