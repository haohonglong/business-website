<?php

namespace app\information\model;

use think\Model;

class Xixin extends Model
{
    
}
