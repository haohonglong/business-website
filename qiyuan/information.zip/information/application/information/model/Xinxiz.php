<?php

namespace app\information\model;

use think\Model;

class Xinxiz extends Model
{
    
}
